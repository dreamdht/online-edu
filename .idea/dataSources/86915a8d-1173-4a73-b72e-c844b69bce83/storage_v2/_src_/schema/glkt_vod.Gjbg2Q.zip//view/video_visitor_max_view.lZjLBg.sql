create view video_visitor_max_view as
select max(`glkt_vod`.`video_visitor`.`id`)   AS `max_id`,
       `glkt_vod`.`video_visitor`.`course_id` AS `course_id`,
       `glkt_vod`.`video_visitor`.`video_id`  AS `video_id`,
       `glkt_vod`.`video_visitor`.`user_id`   AS `user_id`
from `glkt_vod`.`video_visitor`
group by `glkt_vod`.`video_visitor`.`course_id`, `glkt_vod`.`video_visitor`.`video_id`,
         `glkt_vod`.`video_visitor`.`user_id`;

